import numpy as np
import os.path
import PIL
import matplotlib.pyplot as plt

# Open image of cat in numpy
directory = os.path.dirname(os.path.abspath(__file__))
marie_file = os.path.join(directory, 'cat.JPG')
marie_numpy = plt.imread(marie_file)
vaughan_file = os.path.join(directory, 'edandme.JPG')

#Change the color of cat's fur to periwinkle
height = len(marie_numpy)
width = len(marie_numpy[0])
for r in range (height):
    for c in range (width):
        if sum(marie_numpy[r][c])>600 and sum(marie_numpy[r][c])<765:
            marie_numpy[r][c] = [100,111,229]
#Change the color of cat's fur to teal
for r in range (height):
    for c in range (width):
        if sum(marie_numpy[r][c])>500 and sum(marie_numpy[r][c])<600:
            marie_numpy[r][c] = [66,244,232]
marie_pil = PIL.Image.fromarray(marie_numpy)

#open and paste the image of Edward and me and rotate/resize
ed_img = PIL.Image.open(vaughan_file)
edward_img = ed_img.rotate(angle=90, expand=True)
edward_img = edward_img.resize((1000,500))
kat_img_r = marie_pil.rotate(270)
kat_img_r.paste(edward_img,(1850,56))

#Puts blue dots on cat's eyes 
fig, ax = plt.subplots(1,1) 
ax.plot(1917, 1130, 'bo', ms=3)
ax.plot(2183, 1087, 'bo', ms=3)
ax.imshow(kat_img_r, interpolation='none')

fig.show()